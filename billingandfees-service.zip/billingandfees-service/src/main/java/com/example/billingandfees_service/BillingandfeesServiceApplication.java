package com.example.billingandfees_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingandfeesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingandfeesServiceApplication.class, args);
	}

}
