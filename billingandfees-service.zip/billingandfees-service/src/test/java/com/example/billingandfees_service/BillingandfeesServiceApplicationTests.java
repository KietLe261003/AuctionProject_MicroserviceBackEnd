package com.example.billingandfees_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingandfeesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
